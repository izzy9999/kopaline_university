<style type="text/css">
.home >  .pix_diapo , .da-thumbs{
  width: 100%;
}
 .pix_diapo div  img{
    width: 100%;
    height: 100%;
 }
</style>

<div class="home"> 
<div class="pix_diapo">

    <div data-thumb="<?php echo web_root;?>image/Students_happy.jpg"data-time="7000">
        <img src="<?php echo web_root;?>image/Students_happy.jpg">
    </div>

    <div data-thumb="<?php echo web_root;?>image/happy_students.jpg"data-time="7000">
        <img src="<?php echo web_root;?>image/happy_students.jpg"> 
    </div>

    <div data-thumb="<?php echo web_root;?>image/post_office.jpg" data-time="7000">
        <img src="<?php echo web_root;?>image/post_office.jpg">
    </div>       

    
</div><!-- #pix_diapo --> 